# Week 5 DESeq2 interpretation

**Comparison.** `Treated` vs `control` in a 3 × 2 × 2 balanced bulk
RNA-seq design (3 batches × 2 conditions × 2 biological replicates;
n = 12). Design `~ batch + condition` absorbs batch variance first;
LFC values are apeglm-shrunken.

**Strongest QC observation.** On the VST PCA, PC1 (24 % variance)
separates control from treated cleanly; PC2 (9 %) tracks batch —
confirming batch must stay in the design.

**Significant-gene count and direction.** At `padj < 0.05` AND
`|log2FC| ≥ 1`: **60 significant genes (36 up, 24 down in treated)**
out of 989 passing the ≥10-counts-in-≥3-samples filter (from 1000).
Top hit: Gene0035 (padj ≈ 1.3 × 10⁻¹⁰, shrunken log2FC ≈ 1.7).

**Biological interpretation.** A coherent, roughly symmetric shift
with more up- than down-regulated genes — consistent with activation
of a response programme rather than a broad shutdown.

**Limitation.** Only two biological replicates per condition per
batch; the volcano tail between |log2FC| = 1 and 2 is suggestive
rather than definitive.

**AI use.** Volcano styling was drafted with AI; the model, design
formula, coefficient, filtering rule, and biological interpretation
were written and verified independently (see
`week5_AI_verification_log.md`).
