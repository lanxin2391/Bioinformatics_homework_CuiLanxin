# Week 5 AI Verification Log

This log records every place AI assistance was used, the prompt that
was sent, and the independent verification performed afterwards, in
line with the Week-5 Verification Checklist ("AI use" section) and
the in-class slide "Five checks you still own" (Week 5 deck, slide on
AI-assisted interpretation).

---

## Task #1 — Volcano-plot styling (visuals only)

**Where in the script:** section "8. Volcano plot" in
`week5_deseq2_analysis.R`.

**What was asked of the AI.** Produce ggplot2 styling that (a) keeps
the three direction categories ("Up in treated", "Down in treated",
"Not significant") colour-blind-safe, (b) draws both the |log2FC| = 1
threshold lines and the padj = 0.05 horizontal line as dashed
reference lines, and (c) labels axes and the legend clearly.

**Prompt used (verbatim).**

> Generate ggplot2 code for a volcano plot of bulk RNA-seq DESeq2
> results. The data frame has columns `log2FoldChange`, `padj`, and
> `direction` (values "Up in treated", "Down in treated",
> "Not significant"). Colour up = red, down = blue, ns = grey70.
> Draw dashed vertical lines at x = ±1 and a dashed horizontal line at
> y = -log10(0.05). Use theme_bw with base_size 12. Title:
> "Differential expression: treated vs control".

**Independent verification performed.**
1. The returned code was pasted into `week5_deseq2_analysis.R` and
   run locally with `Rscript --vanilla`. The script ran end-to-end
   without error.
2. `args(ggplot2::geom_point)`, `args(ggplot2::scale_color_manual)`,
   `args(ggplot2::geom_vline)` were checked in the R console to
   confirm the function signatures matched the AI's usage.
3. The output PNG `figures/week5_de_plot.png` was opened and visually
   inspected: the three colours are distinguishable in greyscale,
   both threshold lines are present at the expected coordinates, and
   the axis labels match the run-time data (no hallucinated column
   names).
4. The colour choices were checked against the slide's
   recommendation: red for up, blue for down, grey for ns — same
   convention used in the lecture deck.

---

## Checks performed entirely independently (no AI)

| Step | What was done | How it was verified |
|---|---|---|
| Import | `read.csv` with `row.names = 1`, `check.names = FALSE` | `stopifnot` for column–row name match, non-negative integer values |
| Factors | `factor(coldata$condition)`, `relevel(ref = "control")` | `table(batch, condition)` cross-tab printed to stdout |
| Design formula | `~ batch + condition` | Filled in the original TODO comment with a written rationale |
| Filtering rule | `rowSums(counts(dds) >= 10) >= 3` | Recorded as a string in `filter_rule`; printed before/after counts |
| Coefficient name | `resultsNames(dds)` inspected at runtime | Hard-coded `stop()` if the expected pattern does not match exactly; grep pattern `condition_treated_vs_control$` |
| Contrast direction | `contrast = c("condition", "treated", "control")` | Cross-checked against `coldata$condition` levels (treated vs control, not the reverse) |
| Shrinkage | `lfcShrink(coef = target_coef, type = "apeglm")` | Verified `apeglm` is loaded (`packageVersion("apeglm")` printed at start) and citation line printed by apeglm captured in stdout |
| PCA | `vst(dds, blind = FALSE, nsub = min(500, nrow(dds)))` then manual `prcomp` on top 500 variable genes | nsub issue diagnosed independently from the DESeq2 error message; matching `plotPCA` defaults documented in code comments |
| Significance flag | `padj < 0.05 & abs(log2FoldChange) >= 1` | Threshold printed in stdout and on the volcano plot axis as dashed lines |
| Reproducibility | `saveRDS(dds, ...)` and `capture.output(sessionInfo(), ...)` | `session_info.txt` saved alongside `week5_deseq2_object.rds` |

---

## AI errors / revisions encountered

- The first PCA attempt used `DESeq2::plotPCA`, which internally calls
  `vst` with the default `nsub = 1000`. Because only 989 genes
  passed filtering, `vst` refused to run ("less than 'nsub' rows").
  This was **not** an AI error — it was a diagnostic step before any
  AI assistance was used for visuals. Fixed by replacing `vst()` with
  a manual `prcomp` on the top 500 most-variable genes (the standard
  DESeq2 PCA recipe) and explicitly passing `nsub = min(500, nrow(dds))`.

## Five checks I still own (slide on AI-assisted interpretation)

1. ✅ The assay (bulk mRNA polyA+ RNA-seq, integer counts) matches the
   statistical model (DESeq2 negative-binomial on raw counts).
2. ✅ Sample labels in `Week5_Homework_Sample_Metadata.csv` match the
   count-matrix columns one-to-one (verified by `identical()`).
3. ✅ The design formula `~ batch + condition` was chosen because the
   metadata contains three balanced batches; without it PC2 would
   capture batch structure, not noise.
4. ✅ Both PCA and volcano figures visually support the claim that
   treatment produces a clear, symmetric shift; the figures do not
   over-claim mechanism.
5. ✅ All numbers (60 significant genes, 36 up / 24 down, padj range)
   come from the locally run DESeq2 object — no figures or p-values
   were copied from an external source.
