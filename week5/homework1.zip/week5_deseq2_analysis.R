# =============================================================================
# Week 5 Homework — Bulk RNA-seq differential expression with DESeq2 + apeglm
# Course: Bioinformatics: From Multi-Omics Data to Discovery
# Author: generated; run with R 4.4.x + DESeq2 1.46.x + apeglm 1.28.x
#
# Aligned with Verification Checklist (4 sections):
#   Inputs   -> non-negative integer counts, sample identity, factor levels,
#               control as reference
#   Model    -> ~ batch + condition, balance check, resultsNames() inspected,
#               treated-vs-control coefficient confirmed
#   Outputs  -> VST PCA, volcano with axis labels + thresholds,
#               adjusted p values, full table incl. ns genes, RDS + sessionInfo
#   AI use   -> one clearly documented task; AI prompt preserved;
#               generated code run locally; package args verified
# =============================================================================

# ----------------------------
# 0. Project paths
# ----------------------------
proj_dir <- "D:/Grade3/swxxx/week5"
setwd(proj_dir)

count_file    <- "Week5_Homework_Count_Matrix.csv"
metadata_file <- "Week5_Homework_Sample_Metadata.csv"

dir.create("outputs",  showWarnings = FALSE)
dir.create("figures",  showWarnings = FALSE)

# ----------------------------
# 1. Library load (suppress chatty startup)
# ----------------------------
suppressPackageStartupMessages({
  library(DESeq2)        # 1.46.0
  library(apeglm)        # 1.28.0
  library(tidyverse)     # 2.0.0
  library(ggrepel)       # for label-repel on PCA points
  library(matrixStats)   # rowVars() for PCA feature selection
})

cat("\n===== Versions =====\n")
cat("DESeq2 :", as.character(packageVersion("DESeq2")), "\n")
cat("apeglm :", as.character(packageVersion("apeglm")), "\n")
cat("R      :", R.version.string, "\n\n")

# ----------------------------
# 2. Import + mandatory validation  (Verification Checklist: Inputs)
# ----------------------------
counts <- read.csv(count_file, row.names = 1, check.names = FALSE)
coldata <- read.csv(metadata_file, row.names = 1, check.names = FALSE)

# 2.1 Counts must be non-negative integers
stopifnot(ncol(counts) == nrow(coldata))
stopifnot(identical(colnames(counts), rownames(coldata)))
stopifnot(all(counts >= 0))
stopifnot(all(as.matrix(counts) == round(as.matrix(counts))))
stopifnot(!any(duplicated(rownames(coldata))))

# 2.2 Factors + reference level
coldata$condition <- factor(coldata$condition)
coldata$batch     <- factor(coldata$batch)
coldata$condition <- relevel(coldata$condition, ref = "control")

cat("===== Sample cross-tab (batch x condition) =====\n")
print(table(batch = coldata$batch, condition = coldata$condition))

cat("\n===== Library size summary (colSums) =====\n")
print(summary(colSums(counts)))

# ----------------------------
# 3. Construct DESeqDataSet  (Verification Checklist: Model)
# ----------------------------
# Design rationale (TODO comment from Starter.R, filled in here):
#   batch is added FIRST so the model absorbs the technical batch variance
#   before estimating the condition effect. The 3x2 balanced design
#   (3 batches x 2 conditions x 2 biological replicates) keeps the design
#   matrix full rank and makes the batch coefficients identifiable.
#   Removing batch would confound batch with condition (slides 14/26/28).
dds <- DESeqDataSetFromMatrix(
  countData = counts,
  colData   = coldata,
  design    = ~ batch + condition
)

# ----------------------------
# 4. Pre-filter: keep genes with >=10 counts in >=3 samples
# ----------------------------
filter_rule <- "rowSums(counts(dds) >= 10) >= 3"
keep <- eval(parse(text = filter_rule))
cat("\nGenes before filtering:", nrow(dds), "\n")
dds <- dds[keep, ]
cat("Genes after filtering :", nrow(dds), "\n")

# ----------------------------
# 5. Fit model + inspect coefficient names
# ----------------------------
dds <- DESeq(dds)

coef_names <- resultsNames(dds)
cat("\n===== resultsNames(dds) =====\n")
print(coef_names)

# TODO from Starter.R, filled in: we do NOT assume the coefficient name.
# Inspect resultsNames() and pick the last one whose name matches the
# "condition_treated_vs_control" pattern (works regardless of batch levels).
target_coef <- coef_names[grep("condition_treated_vs_control$", coef_names)]
if (length(target_coef) != 1) {
  stop("Could not identify a single treated-vs-control coefficient in: ",
       paste(coef_names, collapse = ", "))
}
target_coef <- target_coef[1]
cat("Target coefficient for shrinkage:", target_coef, "\n")

# ----------------------------
# 6. Extract results + apply apeglm shrinkage
# ----------------------------
res_unshrunk <- results(
  dds,
  contrast = c("condition", "treated", "control"),
  alpha    = 0.05
)

res_shrunk <- lfcShrink(
  dds,
  coef = target_coef,
  type = "apeglm"
)

# Build a tidy data frame with significance flag at the recommended thresholds
# (padj < 0.05 AND |log2FC| >= 1)
res_df <- as.data.frame(res_shrunk) |>
  rownames_to_column("gene_id") |>
  mutate(
    significant = !is.na(padj) & padj < 0.05 & abs(log2FoldChange) >= 1,
    direction   = case_when(
      significant & log2FoldChange >  0 ~ "Up in treated",
      significant & log2FoldChange <  0 ~ "Down in treated",
      TRUE                              ~ "Not significant"
    )
  ) |>
  arrange(padj)

write.csv(
  res_df,
  "outputs/week5_deseq2_results.csv",
  row.names = FALSE
)

cat("\n===== DE summary @ padj<0.05 & |log2FC|>=1 =====\n")
cat("Significant genes:", sum(res_df$significant), "\n")
print(table(res_df$direction))

# ----------------------------
# 7. PCA on VST-transformed data  (Verification Checklist: Outputs)
# ----------------------------
# varianceStabilizingTransformation directly avoids plotPCA's internal
# nsub sampling, which warns/fails on small filtered matrices.
vsd <- vst(dds, blind = FALSE, nsub = min(500, nrow(dds)))

# Manual PCA on the top 500 most-variable genes (standard DESeq2 recipe,
# matches plotPCA defaults but skips the sample-based dispatch).
rv   <- matrixStats::rowVars(assay(vsd))
top  <- order(rv, decreasing = TRUE)[seq_len(min(500, length(rv)))]
pca  <- prcomp(t(assay(vsd)[top, ]))
pct  <- round(100 * (pca$sdev^2 / sum(pca$sdev^2))[1:2])

pca_df <- data.frame(
  name      = colnames(vsd),
  PC1       = pca$x[, 1],
  PC2       = pca$x[, 2],
  condition = colData(vsd)$condition,
  batch     = colData(vsd)$batch
)
percent_var <- pct

p_pca <- ggplot(
  pca_df,
  aes(x = PC1, y = PC2,
      color = condition, shape = batch, label = name)
) +
  geom_point(size = 4) +
  geom_text_repel(size = 3, max.overlaps = Inf) +
  scale_shape_manual(values = c(A = 16, B = 17, C = 15)) +
  labs(
    title = "Week 5 RNA-seq PCA (VST)",
    x     = paste0("PC1: ", percent_var[1], "% variance"),
    y     = paste0("PC2: ", percent_var[2], "% variance"),
    color = "Condition", shape = "Batch"
  ) +
  theme_bw(base_size = 12)

ggsave(
  "figures/week5_pca.png",
  p_pca, width = 7, height = 5, dpi = 300
)

# ----------------------------
# 8. Volcano plot (Verification Checklist: Outputs -> axis labels + thresholds)
# ----------------------------
plot_df <- res_df |>
  mutate(neg_log10_padj = -log10(pmax(padj, 1e-300)))

p_volcano <- ggplot(
  plot_df,
  aes(x = log2FoldChange, y = neg_log10_padj, color = direction)
) +
  geom_point(alpha = 0.7, size = 1.8) +
  geom_vline(xintercept = c(-1, 1), linetype = "dashed") +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed") +
  scale_color_manual(values = c(
    "Up in treated"      = "#C0392B",
    "Down in treated"    = "#2F6DB3",
    "Not significant"    = "grey70"
  )) +
  labs(
    title = "Differential expression: treated vs control",
    x     = "Shrunken log2 fold change (apeglm)",
    y     = "-log10 adjusted p value",
    color = NULL
  ) +
  theme_bw(base_size = 12)

ggsave(
  "figures/week5_de_plot.png",
  p_volcano, width = 7, height = 5, dpi = 300
)

# ----------------------------
# 9. Save fitted DESeq2 object + sessionInfo
# ----------------------------
saveRDS(dds, "outputs/week5_deseq2_object.rds")

capture.output(sessionInfo(), file = "outputs/session_info.txt")

# ----------------------------
# 10. Print quick top hits to stdout (helps when writing the interpretation)
# ----------------------------
cat("\n===== Top 10 shrunken DE genes (by padj) =====\n")
print(
  res_df |>
    filter(significant) |>
    slice_head(n = 10) |>
    select(gene_id, baseMean, log2FoldChange, lfcSE, padj, direction)
)

cat("\nDone. Outputs in ./outputs/, figures in ./figures/.\n")
